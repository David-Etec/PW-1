function validarQuiz() {
    var form = document.fQuiz;
    var respondidas = 0;
    var obrigatorias = ['q1', 'q2', 'q3'];

    obrigatorias.forEach(function (nome) {
        var opcoes = form[nome];
        for (var i = 0; i < opcoes.length; i++) {
            if (opcoes[i].checked) {
                respondidas++;
                break;
            }
        }
    });

    if (respondidas < obrigatorias.length) {
        alert("Por favor, responda todas as perguntas obrigatórias.");
        return false;
    }

    if (form.q4.selectedIndex === 0) {
        alert("Por favor, escolha um tema na pergunta 4.");
        return false;
    }

    alert("Obrigado por responder nosso quiz!");
    return false;
}

function alternarTema() {
    var body = document.body;
    body.classList.toggle('dark');
    var btn = document.getElementById('btn-tema');
    if (!btn) return;
    if (body.classList.contains('dark')) {
        btn.innerHTML = '<i class="bi bi-brightness-high-fill"></i>';
    } else {
        btn.innerHTML = '<i class="bi bi-moon-fill"></i>';
    }
}
function alternarMenu() {
    document.querySelector('.menu').classList.toggle('aberto');
    document.querySelector('.menu-overlay').classList.toggle('aberto');
}

document.addEventListener('keydown', function (e) {
    var menu = document.querySelector('.menu');
    if (e.key === 'Escape' && menu && menu.classList.contains('aberto')) {
        alternarMenu();
    }
});

const data = [
    { title: 'Urso Pardo',
      descricao: 'O urso pardo é um mamífero da família dos ursídeos, com dieta onívora e pelagem que vai do castanho-claro ao escuro. É encontrado em florestas, montanhas e tundras do Hemisfério Norte.',
      link: 'index.html' },
    { title: 'Lobo Cinzento',
      descricao: 'O lobo é um mamífero carnívoro da família dos canídeos, conhecido por sua inteligência e comportamento social em alcateias. É um predador de topo em muitos ecossistemas.',
      link: 'lobo.html' },
    { title: 'Águia',
      descricao: 'A águia é uma ave de rapina conhecida por sua visão aguçada e voo poderoso. Existem mais de 60 espécies ao redor do mundo, e ela é símbolo de força e liberdade em várias culturas.',
      link: 'aguia.html' },
    { title: 'Elefante',
      descricao: 'O elefante é o maior animal terrestre vivo. Conhecido por sua inteligência, memória excepcional e pela tromba, é considerado um engenheiro do ecossistema.',
      link: 'elefante.html' },
];

const cardContainer = document.querySelector('.card-container');
const searchInput = document.querySelector('.search-input');

const displayData = (data) => {
    cardContainer.innerHTML = '';
    data.forEach(e => {
        cardContainer.innerHTML += `
            <div class="card" onclick="window.location.href='${e.link}'">
                <h3>${e.title}</h3>
                <p>${e.descricao}</p>
            </div>
        `;
    });
}

searchInput.addEventListener("keyup", (e) => {
    const search = data.filter(i => i.title.toLowerCase().includes(e.target.value.toLowerCase()));
    displayData(search);
});

window.addEventListener('load', () => displayData(data));